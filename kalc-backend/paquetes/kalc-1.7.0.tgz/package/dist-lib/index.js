/**
 * API pública de Kalc, el motor de fórmulas: lo único que se exporta de la librería.
 * TypeScript puro: nada de Vue ni DOM (lo usan kalc-frontend, en el navegador, y kalc-backend, en Node).
 *
 * Congelada desde la 1.0.0: sacar o cambiar algo de acá rompe a quien la usa y sube la versión
 * major. `index.test.ts` lista lo exportado para que ningún cambio pase sin querer.
 */
export { dependencias, hijos } from "./ast.js";
export { fechaASerie, serieAFecha } from "./calendario.js";
export { codigoSql, ErrorConsulta, parametrosConsulta, sirveComoParametro, } from "./consultas.js";
export { evaluar, evaluarArbol, evaluarComoTabla } from "./evaluador.js";
export { escribirDatos, leerDatos } from "./tablas.js";
// Para las funciones propias: cómo convierte Excel cada argumento.
export { aLogico, argEntero, argNumero, argTexto } from "./funciones/comunes.js";
export { CONTEXTO_EJEMPLOS } from "./funciones/ejemplos.js";
export { buscarFuncion, listarFunciones, registrarFuncion } from "./funciones/registro.js";
export { ErrorSintaxis } from "./lexer.js";
export { parsear } from "./parser.js";
export { aNumero, aTexto, comparar, error, esError, fecha, formatear, logico, numero, numeroATexto, redondear15, texto, textoANumero, VACIO, } from "./valores.js";
export { crearCatalogo, esTabla, esVariable, leerConstante, nombreEnFormula, problemaDeTipo, validarNombre, } from "./variables.js";
//# sourceMappingURL=index.js.map