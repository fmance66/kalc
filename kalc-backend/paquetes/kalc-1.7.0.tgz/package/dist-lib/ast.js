/** Nodos del árbol de una fórmula. Cada uno guarda su posición en el texto. */
/** Los hijos de un nodo, en orden de evaluación. */
export function hijos(n) {
    switch (n.clase) {
        case 'unario':
        case 'porcentaje':
            return [n.operando];
        case 'binario':
            return [n.izquierda, n.derecha];
        case 'llamada':
            return n.argumentos;
        default:
            return [];
    }
}
/**
 * Las variables que nombra la fórmula, sin repetir (sin distinguir mayúsculas), en orden de aparición.
 * `[@Columna]` no cuenta: es una celda de la misma tabla, no otra variable.
 */
export function dependencias(raiz) {
    const vistas = new Map();
    const recorrer = (n) => {
        if (n.clase === 'referencia' && !n.filaActual && !vistas.has(n.nombre.toLowerCase()))
            vistas.set(n.nombre.toLowerCase(), n.nombre);
        hijos(n).forEach(recorrer);
    };
    recorrer(raiz);
    return [...vistas.values()];
}
//# sourceMappingURL=ast.js.map