/**
 * Árbol + contexto → Valor, con las reglas de Excel: coerciones, propagación del primer error,
 * comparación entre tipos y cortocircuito (las funciones reciben los argumentos sin evaluar).
 *
 * Arrays dinámicos, como Excel 365: una tabla, una columna o una función como FILTRAR dan un rango,
 * y las operaciones con un rango (`Ventas[Importe] * 2`, `Ventas[Estado] = 2`) van celda por celda.
 * Como argumento de SUMA, CONTAR.SI, etc., el rango se lee entero; como valor suelto, da #¡VALOR!
 * (salvo una sola celda), y `evaluarComoTabla` lo devuelve como tabla.
 */
import type { Nodo } from './ast.ts';
import { type Tabla } from './tablas.ts';
import { type Valor } from './valores.ts';
export interface Contexto {
    /** Valores de las variables por nombre (sin distinguir mayúsculas), o una función que los busca. */
    variables?: Readonly<Record<string, Valor>> | ((nombre: string) => Valor | undefined);
    /** Las tablas por nombre (sin distinguir mayúsculas), o una función que las busca: `Ventas[Importe]`. */
    tablas?: Readonly<Record<string, Tabla>> | ((nombre: string) => Tabla | undefined);
    /**
     * En una columna calculada, la fila que se está calculando: `[@Alta]` es su celda de la columna
     * Alta (`undefined` si no existe). Sin esto, `[@Alta]` da #¡VALOR!, como en Excel fuera de la tabla.
     */
    fila?: (columna: string) => Valor | undefined;
}
/**
 * Evalúa el texto de una fórmula. Si tiene un error de sintaxis lanza `ErrorSintaxis` (Excel no
 * deja ni escribirla); para mostrar el error con su posición, usar `parsear`.
 */
export declare function evaluar(formula: string, contexto?: Contexto): Valor;
/** Evalúa un árbol ya parseado. Una fórmula nunca da "vacío": como en Excel, `=A` con A vacía da 0. */
export declare function evaluarArbol(arbol: Nodo, contexto?: Contexto): Valor;
/**
 * Evalúa un árbol que puede dar una tabla (`FILTRAR(Ventas; Ventas[Estado] = 2)`, `Ventas[Importe] * 2`):
 * la tabla, con los nombres de las columnas si salen de una; o el valor, si la fórmula da uno solo.
 */
export declare function evaluarComoTabla(arbol: Nodo, contexto?: Contexto): Tabla | Valor;
