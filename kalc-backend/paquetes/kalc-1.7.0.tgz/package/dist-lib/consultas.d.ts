/**
 * Variables de consulta: su valor sale de un SELECT a la base. El motor no sabe de bases de datos:
 * encuentra los parámetros (`:Actividad`) para armar el grafo, y quien usa la librería le da un
 * `EjecutorConsultas` que corre el SQL y devuelve un solo valor, o todas las filas (una tabla).
 */
import type { Posicion } from './lexer.ts';
import type { Tabla } from './tablas.ts';
import type { CodigoError, Valor } from './valores.ts';
/** Lo que recibe el ejecutor: el SQL tal cual y el valor de cada parámetro. */
export interface Consulta {
    /** La variable de la que sale (el servidor puede buscar el SQL guardado por este nombre). */
    nombre: string;
    sql: string;
    /** Por nombre, como está escrito en el SQL (la primera vez que aparece), sin los dos puntos. */
    parametros: Record<string, Valor>;
    /** La variable es de tipo tabla: se esperan todas las filas y columnas, no un solo valor. */
    tabla?: boolean;
    /** En qué base corre, si la variable lo dice (sin esto, la de por defecto de la aplicación). */
    conexion?: string;
}
/**
 * Corre la consulta y devuelve su único valor o, si `consulta.tabla`, todas sus filas. Si no se
 * puede (varias filas para un valor, error de la base), lanza un error: la variable da #¡VALOR!, o
 * el código de un `ErrorConsulta`, con el mensaje. Una tabla para una variable que espera un valor
 * sirve si tiene una sola celda.
 */
export type EjecutorConsultas = (consulta: Consulta) => Promise<Valor | Tabla>;
/** Un error de la consulta con el código que tiene que dar la variable (por ejemplo, #N/D si no hay filas). */
export declare class ErrorConsulta extends Error {
    readonly codigo: CodigoError;
    constructor(codigo: CodigoError, mensaje: string);
}
export interface ParametroConsulta extends Posicion {
    /** Sin los dos puntos. La posición incluye los dos puntos. */
    nombre: string;
}
/** Si la variable se puede usar como parámetro en el SQL (`:nombre`): Oracle no deja espacios ni puntos. */
export declare function sirveComoParametro(nombre: string): boolean;
/**
 * Los parámetros del SQL (`:Actividad`), en orden y con su posición. Los de adentro de textos,
 * identificadores entre comillas y comentarios no cuentan (`'12:30'`), ni las conversiones de
 * PostgreSQL (`fecha::date`).
 */
export declare function parametrosConsulta(sql: string): ParametroConsulta[];
/**
 * El SQL con los textos ('...', q'[...]'), los identificadores entre comillas ("...") y los
 * comentarios tapados con espacios: lo que queda es código, en las mismas posiciones.
 */
export declare function codigoSql(sql: string): string;
