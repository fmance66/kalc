/**
 * Tokens → árbol, por precedencia de operadores (Pratt), con las precedencias de Excel.
 */
import type { Nodo } from './ast.ts';
import { type Posicion } from './lexer.ts';
export type ResultadoParseo = {
    ok: true;
    arbol: Nodo;
} | {
    ok: false;
    error: {
        mensaje: string;
    } & Posicion;
};
export declare function parsear(formula: string): ResultadoParseo;
