/**
 * Tablas: lo que devuelve una variable de tipo `tabla` (las filas de una consulta, una tabla escrita
 * a mano o una fórmula como FILTRAR). Se usan como las tablas de Excel: `Ventas[Importe]` es una
 * columna, `Ventas` la tabla entera. No son un `Valor`: solo las funciones que aceptan rangos (SUMA,
 * BUSCARV, CONTAR.SI…) las leen, y las operaciones (`Ventas[Importe] * 2`) van celda por celda.
 */
import { type Valor, type ValorError } from './valores.ts';
export interface Tabla {
    /** Los nombres de las columnas, como los devuelve la base (se buscan sin distinguir mayúsculas). */
    columnas: string[];
    /** Fila por fila, un valor por columna. NULL es vacío, como una celda sin nada. */
    filas: Valor[][];
}
/** Celdas fila por fila: una tabla entera, una de sus columnas, o el resultado de una operación. */
export type Rango = readonly (readonly Valor[])[];
/** Le asigna nombres a las columnas del rango y lo devuelve. */
export declare function conColumnas<R extends Rango>(r: R, columnas: readonly string[]): R;
/** Los nombres de las columnas; si el rango no sale de una tabla, `Columna1`, `Columna2`… */
export declare function columnasDe(r: Rango): string[];
/** El rango como tabla, con los nombres de sus columnas. */
export declare function aTabla(r: Rango): Tabla;
/** Las filas de la tabla como rango, con sus nombres. */
export declare function rangoDeTabla(t: Tabla): Rango;
/** Una columna por su nombre; si no existe, #¡REF! (como en Excel, una columna que se borró). */
export declare function columnaDe(tabla: Tabla, nombre: string): Rango | ValorError;
/** La posición de la columna, sin distinguir mayúsculas; -1 si no está. */
export declare function indiceDeColumna(columnas: readonly string[], nombre: string): number;
/**
 * Un rango usado como un valor suelto (`=Ventas[Importe]`, `Ventas[Importe] * 2` en una variable que
 * no es de tipo tabla): si es una sola celda, su valor; si no, #¡VALOR!.
 */
export declare function valorDeRango(r: Rango): Valor;
/** Las celdas, fila por fila, en una sola lista. */
export declare function celdasDe(r: Rango): Valor[];
/** Cantidad de columnas: la de la primera fila (todas tienen las mismas). */
export declare function anchoDe(r: Rango): number;
/**
 * Una tabla escrita como texto: la primera línea son los nombres de las columnas y cada una de las
 * siguientes, una fila. Las celdas se separan con `;` o con tabulaciones (lo que queda al pegar desde
 * Excel). Cada celda se lee como en una constante: `1.234,5`, `31/12/2026`, `VERDADERO`; vacía es
 * una celda vacía, y entre comillas (`"100"`) es un texto.
 */
export declare function leerDatos(escrito: string): {
    ok: true;
    tabla: Tabla;
} | {
    ok: false;
    mensaje: string;
};
/** La tabla como texto, para editarla: lo que `leerDatos` vuelve a leer igual. */
export declare function escribirDatos(tabla: Tabla): string;
