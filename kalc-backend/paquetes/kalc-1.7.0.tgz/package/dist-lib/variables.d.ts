/**
 * Variables con nombre: cada una es una constante, una fórmula que usa otras, una consulta a la base
 * (con otras como parámetros) o, si es de tipo tabla, datos escritos a mano; una tabla puede sumar
 * columnas calculadas fila por fila. El catálogo arma el grafo de dependencias, calcula en orden
 * topológico, marca los ciclos y, al cambiar una variable, recalcula solo las que dependen de ella.
 */
import { type EjecutorConsultas } from './consultas.ts';
import { type Contexto } from './evaluador.ts';
import type { Posicion } from './lexer.ts';
import { type Tabla } from './tablas.ts';
import { type Valor } from './valores.ts';
/**
 * El tipo esperado del resultado. `entero` es un número sin decimales (Excel no los distingue).
 * `tabla`: filas y columnas (de una consulta, una fórmula como FILTRAR o datos escritos a mano),
 * que las fórmulas usan como `Ventas[Importe]`.
 */
export type TipoVariable = 'numero' | 'entero' | 'texto' | 'logico' | 'fecha' | 'tabla';
export interface Variable {
    nombre: string;
    tipo: TipoVariable;
    origen: {
        clase: 'constante';
        valor: Valor;
    }
    /** De tipo tabla, puede dar una tabla: `FILTRAR(Ventas; Ventas[Estado] = 2)`. */
     | {
        clase: 'formula';
        texto: string;
    }
    /**
     * Un SELECT que devuelve un solo valor (o filas, si es de tipo tabla); `:Nombre` es otra variable,
     * como parámetro. `conexion`: en qué base corre, si la aplicación tiene varias (sin ella, la de
     * por defecto).
     */
     | {
        clase: 'consulta';
        sql: string;
        conexion?: string;
    }
    /** Una tabla escrita a mano (alícuotas, topes): ver `leerDatos` y `escribirDatos`. */
     | {
        clase: 'datos';
        tabla: Tabla;
    };
    /** De tipo tabla: columnas que se le agregan, calculadas fila por fila. */
    columnas?: ColumnaCalculada[];
    descripcion?: string;
}
/**
 * Una columna calculada: la fórmula se calcula para cada fila de la tabla, y `[@Alta]` es la celda
 * de esa fila en la columna Alta (también las calculadas antes). Puede usar otras variables y la
 * misma tabla entera (`[@Monto] / SUMA(Causas[Monto])`), sin que sea un ciclo.
 */
export interface ColumnaCalculada {
    nombre: string;
    formula: string;
}
/** Por qué una variable no tiene el valor que se espera. */
export type Problema = ({
    clase: 'sintaxis';
    mensaje: string;
} & Posicion)
/** El camino del ciclo, empezando y terminando en la variable: `['A', 'B', 'A']`. */
 | {
    clase: 'ciclo';
    camino: string[];
}
/** Nombra variables que no existen (dan #¿NOMBRE?). */
 | {
    clase: 'faltan';
    nombres: string[];
}
/** El resultado no es del tipo declarado: se avisa, no se convierte. */
 | {
    clase: 'tipo';
    mensaje: string;
}
/** Una consulta que todavía no se corrió con estos parámetros (vale #N/D): ver `resolverConsultas`. */
 | {
    clase: 'pendiente';
}
/** La consulta falló: el motivo que dio el ejecutor (varias filas, error de la base…). */
 | {
    clase: 'consulta';
    mensaje: string;
}
/** Una columna calculada no se puede calcular: error de sintaxis, nombre repetido. */
 | {
    clase: 'columna';
    columna: string;
    mensaje: string;
};
export interface EstadoVariable {
    /** De una tabla: su valor como si fuera una celda (#¡VALOR! si tiene más de una). */
    valor: Valor;
    /** Las filas de una variable de tipo tabla, ya resuelta. */
    tabla?: Tabla;
    /** Las variables que nombra la fórmula (o los parámetros de la consulta), como están escritas. */
    dependencias: string[];
    problema?: Problema;
}
export interface Catalogo {
    /** Las variables, en el orden en que se agregaron. */
    variables(): Variable[];
    buscar(nombre: string): Variable | undefined;
    estado(nombre: string): EstadoVariable | undefined;
    /** Para evaluar otras fórmulas con los valores del catálogo. */
    contexto(): Contexto;
    /**
     * Agrega o reemplaza una variable (por nombre, sin distinguir mayúsculas) y recalcula ella y las
     * que dependen de ella. Devuelve las recalculadas, en orden de cálculo.
     */
    definir(variable: Variable): string[];
    /** Las que dependían de ella pasan a dar #¿NOMBRE?. */
    quitar(nombre: string): string[];
    /**
     * Le cambia el nombre y corrige las fórmulas que la usan, como Excel con los nombres definidos.
     * Lanza un error si el nombre nuevo no es válido o ya existe.
     */
    renombrar(anterior: string, nuevo: string): string[];
    /** Recalcula una variable y sus dependientes, o todas (por las funciones volátiles como HOY). */
    recalcular(nombre?: string): string[];
    /**
     * Corre las consultas pendientes con el ejecutor y recalcula lo que depende de ellas, por tandas
     * (una consulta que usa otra como parámetro espera a la primera). Con `refrescar` corre también
     * las que ya tenían resultado (los datos de la base cambian): todas, o las de la lista.
     * Devuelve las recalculadas.
     */
    resolverConsultas(ejecutor: EjecutorConsultas, opciones?: {
        refrescar?: boolean | readonly string[];
    }): Promise<string[]>;
}
/** El motivo por el que el nombre no sirve, o `null` si sirve. */
export declare function validarNombre(nombre: string): string | null;
/** Cómo se escribe la variable en una fórmula: `Alicuota`, o `[Base imponible]` si hace falta. */
export declare function nombreEnFormula(nombre: string): string;
/**
 * El valor de una constante escrita como texto, según su tipo: `1.234,5`, `31/12/2026`,
 * `VERDADERO`. Vacío es una variable sin valor (como una celda vacía).
 */
export declare function leerConstante(escrito: string, tipo: TipoVariable): {
    ok: true;
    valor: Valor;
} | {
    ok: false;
    mensaje: string;
};
/** Si el valor no es del tipo declarado, el motivo. Un error o un vacío no es un problema de tipo. */
export declare function problemaDeTipo(valor: Valor, tipo: TipoVariable): string | null;
/** Para leer variables de un JSON (importado o guardado): si tiene la forma de una `Variable`. */
export declare function esVariable(x: unknown): x is Variable;
/** Para leer una tabla de un JSON (la respuesta del servidor): columnas de texto y filas de valores. */
export declare function esTabla(x: unknown): x is Tabla;
export declare function crearCatalogo(variables?: readonly Variable[]): Catalogo;
