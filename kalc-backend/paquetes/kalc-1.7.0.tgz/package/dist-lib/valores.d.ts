/**
 * Tipos de valor y coerciones. Excel tiene tipos aunque no se vean (número, texto, lógico,
 * error, celda vacía) y para dar sus mismos resultados hay que modelarlos.
 */
export type CodigoError = '#¡DIV/0!' | '#¡VALOR!' | '#¿NOMBRE?' | '#¡REF!' | '#N/D' | '#¡NUM!' | '#¡CICLO!';
export type Valor = {
    tipo: 'numero';
    valor: number;
} | {
    tipo: 'texto';
    valor: string;
} | {
    tipo: 'logico';
    valor: boolean;
}
/** Número de serie de Excel (días desde 1899-12-30, ver calendario.ts). Opera como número. */
 | {
    tipo: 'fecha';
    valor: number;
} | {
    tipo: 'error';
    valor: CodigoError;
}
/** Como una celda vacía: 0 en aritmética, "" en texto, FALSO en lógica. */
 | {
    tipo: 'vacio';
};
export type ValorError = Extract<Valor, {
    tipo: 'error';
}>;
/** Códigos de error que se aceptan escritos en una fórmula; el nombre en inglés es alias. */
export declare const ERRORES: Readonly<Record<string, CodigoError>>;
export declare const numero: (valor: number) => Valor;
export declare const texto: (valor: string) => Valor;
export declare const logico: (valor: boolean) => Valor;
export declare const fecha: (valor: number) => Valor;
export declare const error: (valor: CodigoError) => ValorError;
export declare const VACIO: Valor;
export declare const esError: (v: Valor) => v is ValorError;
/** Excel no admite textos más largos (el & devuelve #¡VALOR!). */
export declare const LARGO_MAXIMO_TEXTO = 32767;
/**
 * Excel trabaja con 15 dígitos significativos: 0,1 + 0,2 muestra 0,3 y `=0,1+0,2=0,3` da
 * VERDADERO. Se redondea así al mostrar y al comparar (no en los cálculos intermedios).
 */
export declare function redondear15(n: number): number;
/**
 * A número, para la aritmética: `"3" + 1 = 4`, `VERDADERO + 1 = 2`, vacío = 0. Un texto que no
 * es un número (ni una fecha) da #¡VALOR!, incluido "" y "VERDADERO".
 */
export declare function aNumero(v: Valor): number | ValorError;
/** A texto, para el &: los números como en el formato General de Excel (`1,5`, `1E+15`). */
export declare function aTexto(v: Valor): string | ValorError;
/** Si el texto es una fecha válida escrita como dd/mm/aaaa. */
export declare function esTextoFecha(s: string): boolean;
/**
 * Un texto escrito como lo entendería Excel en castellano (Argentina): `1.234,5`, `-3`, `50%`,
 * `1,5E+3`, `$ 100`, o una fecha `31/12/2026`. `null` si no es un número.
 */
export declare function textoANumero(s: string): number | null;
/**
 * Un número como lo escribe Excel en una concatenación (formato General, 15 dígitos
 * significativos, coma decimal, sin separador de miles). Notación científica desde 1E+15 y por
 * debajo de 1E-9.
 */
export declare function numeroATexto(n: number): string;
/** -1, 0 o 1. Los errores ya se descartaron antes. */
export declare function comparar(a: Valor, b: Valor): number;
/**
 * El valor para mostrar en pantalla: `1234,56`, `31/12/2026`, `VERDADERO`, `#¡DIV/0!`. Los números
 * en formato General, como Excel: sin separador de miles (un año se ve 2026, no 2.026).
 */
export declare function formatear(v: Valor): string;
