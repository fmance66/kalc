/**
 * Variables de consulta: su valor sale de un SELECT a la base. El motor no sabe de bases de datos:
 * encuentra los parámetros (`:Actividad`) para armar el grafo, y quien usa la librería le da un
 * `EjecutorConsultas` que corre el SQL y devuelve un solo valor, o todas las filas (una tabla).
 */
/** Un error de la consulta con el código que tiene que dar la variable (por ejemplo, #N/D si no hay filas). */
export class ErrorConsulta extends Error {
    codigo;
    constructor(codigo, mensaje) {
        super(mensaje);
        this.name = 'ErrorConsulta';
        this.codigo = codigo;
    }
}
/** Lo que Oracle acepta como nombre de bind sin comillas. */
const NOMBRE_PARAMETRO = /^[\p{L}][\p{L}\p{N}_$#]*$/u;
// `x::int` es una conversión de PostgreSQL, no el parámetro `:int`.
const PARAMETRO = /(?<!:):([\p{L}][\p{L}\p{N}_$#]*)/gu;
/** q'[...]', q'{...}', q'<...>', q'(...)' o q'X...X': el texto alternativo de Oracle. */
const CIERRE_Q = { '[': ']', '{': '}', '<': '>', '(': ')' };
/** Si la variable se puede usar como parámetro en el SQL (`:nombre`): Oracle no deja espacios ni puntos. */
export function sirveComoParametro(nombre) {
    return NOMBRE_PARAMETRO.test(nombre);
}
/**
 * Los parámetros del SQL (`:Actividad`), en orden y con su posición. Los de adentro de textos,
 * identificadores entre comillas y comentarios no cuentan (`'12:30'`), ni las conversiones de
 * PostgreSQL (`fecha::date`).
 */
export function parametrosConsulta(sql) {
    return [...codigoSql(sql).matchAll(PARAMETRO)].map((m) => ({ nombre: m[1], inicio: m.index, fin: m.index + m[0].length }));
}
/**
 * El SQL con los textos ('...', q'[...]'), los identificadores entre comillas ("...") y los
 * comentarios tapados con espacios: lo que queda es código, en las mismas posiciones.
 */
export function codigoSql(sql) {
    let r = '';
    let i = 0;
    const tapar = (fin) => {
        r += sql.slice(i, fin).replace(/[^\n]/g, ' ');
        i = fin;
    };
    while (i < sql.length) {
        const c = sql[i];
        const siguiente = sql[i + 1];
        const hasta = (marca, desde) => {
            const fin = sql.indexOf(marca, desde);
            return fin < 0 ? sql.length : fin + marca.length;
        };
        if (c === '-' && siguiente === '-')
            tapar(hasta('\n', i));
        else if (c === '/' && siguiente === '*')
            tapar(hasta('*/', i + 2));
        else if ((c === 'q' || c === 'Q') && siguiente === "'" && !/[\p{L}\p{N}_$#]/u.test(sql[i - 1] ?? '')) {
            const apertura = sql[i + 2] ?? '';
            tapar(hasta((CIERRE_Q[apertura] ?? apertura) + "'", i + 3));
        }
        // '' adentro de un texto es una comilla: se tapa igual, como dos textos seguidos.
        else if (c === "'" || c === '"')
            tapar(hasta(c, i + 1));
        else
            r += sql[i++];
    }
    return r;
}
//# sourceMappingURL=consultas.js.map