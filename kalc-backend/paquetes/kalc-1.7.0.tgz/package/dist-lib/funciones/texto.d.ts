/**
 * Texto: CONCAT, IZQUIERDA, DERECHA, EXTRAE, LARGO, MAYUSC, MINUSC, ESPACIOS, TEXTO, VALOR, HALLAR,
 * ENCONTRAR y CONTIENE (propia de Kalc). Todas menos CONCAT son de un valor (`porCelda`): con una
 * columna, van celda por celda.
 */
import type { DefinicionFuncion } from './registro.ts';
export declare const TEXTO: DefinicionFuncion[];
