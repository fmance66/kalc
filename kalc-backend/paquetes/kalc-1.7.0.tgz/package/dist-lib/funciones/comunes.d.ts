/** Lo que comparten las funciones: cómo convierte Excel cada argumento y cómo redondea. */
import type { Argumento } from './registro.ts';
import { type Rango } from '../tablas.ts';
import { type Valor, type ValorError } from '../valores.ts';
/** El argumento como número (`"3"` → 3, VERDADERO → 1, vacío → 0). */
export declare function argNumero(a: Argumento | undefined): number | ValorError;
/** Como `argNumero`, sin decimales: Excel trunca las cantidades (`IZQUIERDA("abc";1,9)` toma 1). */
export declare function argEntero(a: Argumento | undefined): number | ValorError;
export declare function argTexto(a: Argumento | undefined): string | ValorError;
/**
 * A lógico, para las condiciones: un número es VERDADERO si no es 0; vacío es FALSO; el texto
 * "VERDADERO"/"FALSO" (o en inglés) se acepta, cualquier otro texto da #¡VALOR!.
 */
export declare function aLogico(v: Valor): boolean | ValorError;
/**
 * El valor que devuelven `SI`, `SI.ERROR`, etc.: un argumento omitido (`SI(VERDADERO;)`) da 0,
 * como en Excel; una variable vacía sigue vacía (se comporta como la celda).
 */
export declare function resultado(a: Argumento | undefined): Valor;
/**
 * El rango del argumento, para las funciones que solo aceptan rangos (`CONTAR.SI`, `BUSCARV`). Un
 * valor suelto cuenta como un rango de una celda (Excel no deja escribir eso, pero acepta una celda).
 */
export declare function rangoDe(a: Argumento | undefined): Rango | ValorError;
/**
 * Los valores del argumento uno por uno: las celdas de una tabla o columna, o el valor solo.
 * `celdas` dice si salen de una variable o un rango (Excel los trata como celdas: ignora el texto).
 */
export declare function valoresDe(a: Argumento): {
    valores: Valor[];
    celdas: boolean;
} | ValorError;
/**
 * Los números de `SUMA`, `PROMEDIO`, `MIN` y `MAX`. Como en Excel: un valor escrito directo se
 * convierte (`SUMA("3";VERDADERO)` = 4, `SUMA("abc")` = #¡VALOR!), pero de una variable, una tabla
 * o una columna solo cuentan los números y las fechas (el texto, los lógicos y el vacío se ignoran,
 * como en una celda). Los errores siempre se propagan. `fechas` dice si todos los que contaron eran
 * fechas.
 */
export declare function numerosDe(args: readonly Argumento[]): {
    numeros: number[];
    fechas: boolean;
} | ValorError;
/** `x^y` con los errores de Excel. */
export declare function potencia(x: number, y: number): Valor;
/** Cómo resolver el último dígito: `mitad` (REDONDEAR), `afuera` (.MAS), `adentro` (.MENOS, TRUNCAR). */
export type ModoRedondeo = 'mitad' | 'afuera' | 'adentro';
/**
 * Redondea a `digitos` decimales (negativos: decenas, centenas) como Excel: la mitad se aleja del
 * cero (`REDONDEAR(-2,5;0)` = -3, no el redondeo de `Math.round`), y se trabaja sobre los 15
 * dígitos que muestra Excel, así `REDONDEAR(2,675;2)` da 2,68 aunque el double sea 2,67499…
 */
export declare function redondearA(n: number, digitos: number, modo: ModoRedondeo): number;
