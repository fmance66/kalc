/**
 * La tabla que usan los ejemplos de las funciones de tablas (`SUMAR.SI(Causas[Fuero]; …)`): el
 * catálogo los evalúa con este contexto, así se calculan sin una base. Datos inventados.
 */
import type { Contexto } from '../evaluador.ts';
import type { Tabla } from '../tablas.ts';
/** Con qué se evalúan los ejemplos del registro: la tabla Causas (causa, fuero, monto, fojas). */
export declare const CONTEXTO_EJEMPLOS: Readonly<Contexto> & {
    tablas: Readonly<Record<string, Tabla>>;
};
