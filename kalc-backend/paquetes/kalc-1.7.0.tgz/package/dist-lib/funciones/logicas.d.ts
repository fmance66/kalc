/** Lógicas: SI, Y, O, NO, SI.ERROR, SI.CONJUNTO, CAMBIAR, VERDADERO, FALSO. */
import type { DefinicionFuncion } from './registro.ts';
export declare const LOGICAS: DefinicionFuncion[];
