/**
 * Matemáticas y trigonométricas: SUMA, PROMEDIO, MIN, MAX, redondeos, ENTERO, ABS, RESIDUO,
 * POTENCIA, RAIZ, logaritmos, EXP, PI y las trigonométricas (en radianes, como en Excel).
 */
import type { DefinicionFuncion } from './registro.ts';
export declare const MATEMATICAS: DefinicionFuncion[];
