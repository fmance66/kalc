/** Información: ESNUMERO, ESTEXTO, ESBLANCO, ESERROR. Nunca dan error: dicen qué tipo de valor hay. */
import type { DefinicionFuncion } from './registro.ts';
export declare const INFORMACION: DefinicionFuncion[];
