/**
 * Búsqueda en tablas: BUSCARV, BUSCARX, COINCIDIR, INDICE, FILAS, COLUMNAS. Los ejemplos usan la
 * tabla Causas de CONTEXTO_EJEMPLOS.
 */
import type { DefinicionFuncion } from './registro.ts';
export declare const BUSQUEDA: DefinicionFuncion[];
