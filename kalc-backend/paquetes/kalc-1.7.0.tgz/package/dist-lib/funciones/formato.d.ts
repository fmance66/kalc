/**
 * Códigos de formato de Excel en castellano (Argentina), para TEXTO: `,` decimal, `.` de miles,
 * `aaaa` para el año. Se cubre lo común: `0`, `#`, `?`, miles, `%`, texto entre comillas,
 * secciones `positivo;negativo;cero`, y fechas y horas (`dd/mm/aaaa`, `mmmm`, `hh:mm:ss`).
 * Sin colores, condiciones (`[>100]`) ni AM/PM: esas partes se ignoran.
 */
/** El número con el formato, o `null` si no se puede (una fecha negativa). */
export declare function aplicarFormato(n: number, formato: string): string | null;
