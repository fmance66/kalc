/**
 * Conteos y sumas con condición: CONTAR, CONTARA, CONTAR.BLANCO, CONTAR.SI, CONTAR.SI.CONJUNTO,
 * SUMAR.SI, SUMAR.SI.CONJUNTO, PROMEDIO.SI. Las de condición trabajan sobre tablas y columnas
 * (`Ventas[Importe]`); los ejemplos usan la tabla Causas de CONTEXTO_EJEMPLOS.
 */
import type { DefinicionFuncion } from './registro.ts';
export declare const ESTADISTICAS: DefinicionFuncion[];
