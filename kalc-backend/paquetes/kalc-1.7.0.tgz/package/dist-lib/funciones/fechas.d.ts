/** Fechas: HOY, FECHA, AÑO, MES, DIA, DIAS, FIN.MES, FECHA.MES. Trabajan con números de serie. */
import type { DefinicionFuncion } from './registro.ts';
export declare const FECHAS: DefinicionFuncion[];
