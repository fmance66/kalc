/**
 * Criterios y coincidencias, como los entiende Excel: el criterio de `CONTAR.SI` / `SUMAR.SI`
 * (`5`, `">100"`, `"<>"`, `"a*"`) y la búsqueda de un valor en un rango (`BUSCARV`, `COINCIDIR`).
 */
import { type Valor } from '../valores.ts';
/** Si la celda cumple el criterio. */
export type Criterio = (celda: Valor) => boolean;
/**
 * El criterio de `CONTAR.SI`, `SUMAR.SI`, etc. Un texto puede empezar con un operador (`">100"`,
 * `"<>Baja"`); sin operador es `=`. Como en Excel:
 * - Un número (o un texto que es un número, `"100"`, `"31/12/2026"`) con `=` coincide con las celdas
 *   que tienen ese número, también escrito como texto. Con `<`, `>`, etc., solo con números.
 * - Un texto con `=` o `<>` admite comodines: `*` (cualquier cosa), `?` (un carácter), `~*` (un
 *   asterisco). Sin distinguir mayúsculas.
 * - `""` o `"="` coincide con las celdas vacías; `"<>"`, con las que tienen algo.
 * - `<>` es la negación de `=`: `"<>5"` cuenta también las vacías y las de texto.
 */
export declare function criterio(v: Valor): Criterio;
/** Una celda vacía, o con un texto vacío (Excel no las distingue en los criterios). */
export declare const esVacia: Criterio;
/**
 * Los comodines de Excel como expresión regular, sin distinguir mayúsculas: `*` cualquier cosa,
 * `?` un carácter, `~` delante de `*`, `?` o `~` los toma literales. Con `entero` (por defecto) el
 * patrón tiene que coincidir con todo el texto, como en un criterio; sin él, con una parte, como
 * en HALLAR.
 */
export declare function comodines(patron: string, entero?: boolean): RegExp;
/**
 * La posición (desde 0) de `buscado` en la lista, o -1. Como en Excel:
 * - `exacta`: la primera igual, del mismo tipo (el número 1 no encuentra el texto "1"), sin
 *   distinguir mayúsculas y con comodines si lo buscado es un texto.
 * - `menor`: la última menor o igual (los datos tienen que estar en orden ascendente).
 * - `mayor`: la última mayor o igual (en orden descendente).
 * En las aproximadas se recorre hasta pasarse; Excel hace una búsqueda binaria, y con los datos
 * ordenados (lo que pide) da lo mismo.
 */
export declare function buscar(buscado: Valor, lista: readonly Valor[], modo: 'exacta' | 'menor' | 'mayor'): number;
