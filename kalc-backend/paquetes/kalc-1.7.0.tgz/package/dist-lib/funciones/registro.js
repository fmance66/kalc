/**
 * Registro de funciones. Cada función recibe sus argumentos **sin evaluar** (thunks) y decide
 * cuáles evaluar: así `SI`, `SI.ERROR`, `SI.CONJUNTO` y `CAMBIAR` hacen cortocircuito como en
 * Excel. (`Y` y `O` no: en Excel evalúan todo, y `Y(FALSO;1/0)` da #¡DIV/0!).
 */
import { BUSQUEDA } from "./busqueda.js";
import { ESTADISTICAS } from "./estadisticas.js";
import { MATRICES } from "./matrices.js";
import { FECHAS } from "./fechas.js";
import { INFORMACION } from "./informacion.js";
import { LOGICAS } from "./logicas.js";
import { MATEMATICAS } from "./matematicas.js";
import { TEXTO } from "./texto.js";
const registro = new Map();
/** Agrega (o reemplaza) una función: también sirve para las funciones propias del negocio. */
export function registrarFuncion(def) {
    for (const nombre of [def.nombre, ...(def.alias ?? [])])
        registro.set(nombre.toUpperCase(), def);
}
export function buscarFuncion(nombre) {
    return registro.get(nombre.toUpperCase());
}
/** Las funciones registradas, una vez cada una (sin los alias). */
export function listarFunciones() {
    return [...new Set(registro.values())];
}
for (const def of [...LOGICAS, ...MATEMATICAS, ...ESTADISTICAS, ...BUSQUEDA, ...MATRICES, ...TEXTO, ...INFORMACION, ...FECHAS])
    registrarFuncion(def);
//# sourceMappingURL=registro.js.map