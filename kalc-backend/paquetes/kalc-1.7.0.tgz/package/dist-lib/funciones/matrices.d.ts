/**
 * Funciones que devuelven una tabla (arrays dinámicos de Excel 365): FILTRAR, ORDENAR, UNICOS,
 * ELEGIRCOLS, TOMAR. Una variable de tipo tabla puede ser una fórmula con ellas, y sirven como
 * argumento de otras (`FILAS(FILTRAR(…))`). Los ejemplos usan la tabla Causas de CONTEXTO_EJEMPLOS.
 */
import type { DefinicionFuncion } from './registro.ts';
export declare const MATRICES: DefinicionFuncion[];
