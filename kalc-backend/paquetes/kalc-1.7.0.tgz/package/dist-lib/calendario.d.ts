/**
 * Números de serie de fecha de Excel (sistema 1900): la serie 1 es el 01/01/1900.
 *
 * Excel arrastra un error de Lotus 1-2-3: cree que 1900 fue bisiesto, así que la serie 60 es el
 * inexistente 29/02/1900 y desde la 61 (01/03/1900) todo queda corrido un día. Se respeta para que
 * los números coincidan con los de Excel: desde el 01/03/1900 la serie es "días desde el
 * 30/12/1899", y antes, "días desde el 31/12/1899".
 */
export interface FechaCivil {
    anio: number;
    mes: number;
    dia: number;
}
/** Último día que Excel acepta: 31/12/9999. */
export declare const SERIE_MAXIMA = 2958465;
/** La serie de una fecha, o `null` si no existe (31/02) o está fuera del rango de Excel. */
export declare function fechaASerie({ anio, mes, dia }: FechaCivil): number | null;
/** La fecha de una serie (se descarta la parte fraccionaria: la hora). `null` fuera de rango. */
export declare function serieAFecha(serie: number): FechaCivil | null;
