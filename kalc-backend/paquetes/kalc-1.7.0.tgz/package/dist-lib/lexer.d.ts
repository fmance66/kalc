/**
 * Texto → tokens, con la sintaxis de Excel en castellano (Argentina): `;` separa argumentos y
 * `,` es el separador decimal.
 */
import { type CodigoError } from './valores.ts';
/** Posición en el texto de la fórmula (inicio incluido, fin excluido), para subrayar en la UI. */
export interface Posicion {
    inicio: number;
    fin: number;
}
export type Operador = '+' | '-' | '*' | '/' | '^' | '&' | '%' | '=' | '<>' | '<' | '>' | '<=' | '>=';
export type Token = Posicion & ({
    clase: 'numero';
    valor: number;
} | {
    clase: 'texto';
    valor: string;
} | {
    clase: 'error';
    valor: CodigoError;
}
/**
 * Nombre de función, de variable, o VERDADERO/FALSO (lo decide el parser). Con `columna`, una
 * columna de una tabla: `Ventas[Importe]` (el corchete pegado al nombre). Con `filaActual`, la
 * celda de la fila que se calcula: `[@Importe]` (sin nombre) o `Ventas[@Importe]`.
 */
 | {
    clase: 'nombre';
    valor: string;
    entreCorchetes: boolean;
    columna?: string;
    filaActual?: boolean;
} | {
    clase: 'operador';
    valor: Operador;
} | {
    clase: '(' | ')' | ';' | 'fin';
});
export declare class ErrorSintaxis extends Error {
    readonly posicion: Posicion;
    /** `posicion` puede ser un token o un nodo: se guarda solo inicio y fin. */
    constructor(mensaje: string, { inicio, fin }: Posicion);
}
export declare function tokenizar(formula: string): Token[];
